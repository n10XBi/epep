const fetch = require('node-fetch');

exports.run = {
   usage: [
      'ai-image',
      'aiimg-raava',
      'aiimg-animefy',
      'aiimg-simurg',
      'aiimg-prodia',
      'aiimg-lexica',
      'aiimg-v1',
      'aiimg-v2',
      'aiimg-v2beta'
   ],
   use: 'prompt',
   category: 'ai',
   async: async (m, { client, text, Func, command }) => {
      try {
         let model;

         if (command === 'ai-image') {
            model = 'v3';
         } else if (command === 'aiimg-raava') {
            model = 'raava';
         } else if (command === 'aiimg-animefy') {
            model = 'animefy';
         } else if (command === 'aiimg-simurg') {
            model = 'simurg';
         } else if (command === 'aiimg-prodia') {
            model = 'prodia';
         } else if (command === 'aiimg-lexica') {
            model = 'lexica';
         } else if (command === 'aiimg-v1') {
            model = 'v1';
         } else if (command === 'aiimg-v2') {
            model = 'v2';
         } else if (command === 'aiimg-v2beta') {
            model = 'v2beta';
         } else {
            return client.reply(m.chat, '❌ Unknown Hercai model. Available models: hercai-image, aiimg-raava, aiimg-animefy, aiimg-simurg, aiimg-prodia, aiimg-lexica, aiimg-v1, aiimg-v2, aiimg-v2beta', m);
         }

         if (!text) return client.reply(m.chat, `• Example: ${command} cat`, m);
         client.sendReact(m.chat, '🕒', m.key);

         const url = `https://hercai.onrender.com/${model}/text2image?prompt=${encodeURIComponent(text)}`;
         const response = await fetch(url);
         const json = await response.json();

         if (json.url) {
            // Mengambil buffer gambar dari URL
            const imageBuffer = await fetch(json.url).then(res => res.buffer());

            // Mengirim gambar sebagai file JPG
            client.sendFile(m.chat, imageBuffer, 'image.jpg', `This is the result from ${text}`, m);
            client.sendReact(m.chat, '✅', m.key);
         } else {
            client.reply(m.chat, '❌ ' + (json.url === 'in maintenance' ? 'Hercai service is currently in maintenance' : 'Failed to generate AI image. Please try again later.'), m);
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.texted('bold', '❌ An error occurred while processing your request. Please try again later.'), m);
      }
   },
   error: false,
   limit: true,
   location: __filename,
};