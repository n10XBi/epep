const axios = require('axios');

exports.run = {
   usage: ['+saldo'],
   use: 'number|jumlah', 
   category: 'owner',
   async: async (m, { client, text, Func }) => {
      try {
         if (!text) {
            return client.reply(m.chat, 'Format yang Anda masukkan salah. Silakan gunakan format yang benar, contoh: +saldo +62 857-9358-9243 | 5000', m);
         }

         const [number, amountStr] = text.split('|');
         if (!number || !amountStr) return client.reply(m.chat, 'Format yang Anda masukkan salah. Silakan gunakan format yang benar, contoh: -saldo +62 857-9358-9243 | 5000', m);
         const amount = parseInt(amountStr.trim());

         if (isNaN(amountStr)) {
            return client.reply(m.chat, 'Jumlah saldo yang dimasukkan tidak valid.', m);
         }

         const filteredNumber = filterNumber(number.trim());
         const user = await findUserByNumber(filteredNumber);

         if (!user) {
            return client.reply(m.chat, 'Pengguna dengan nomor ini tidak ditemukan.', m);
         }

         // Tambahkan saldo ke user
         user.saldo += amount;

         // Simpan perubahan ke dalam account.json
         await updateAccountJson(user);

         client.reply(m.chat, `Saldo berhasil ditambahkan. Saldo baru untuk nomor ${filteredNumber}: ${Func.formatNumber(user.saldo)}`, m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, 'Terjadi kesalahan dalam menambahkan saldo.', m);
      }
   },
   error: false,
   owner: true,
   location: __filename
};

// Fungsi untuk mencari user berdasarkan nomor
async function findUserByNumber(number) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Cari user berdasarkan nomor
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const [, , userNumber] = key.split('°'); // Ambil nomor dari key

            if (userNumber === number) {
               return {
                  key: key,
                  saldo: userInfo.saldo
               };
            }
         }
      }

      return null; // Pengguna tidak ditemukan
   } catch (error) {
      console.error('Gagal menemukan pengguna berdasarkan nomor:', error.message);
      throw error;
   }
}

// Fungsi untuk memperbarui saldo dalam account.json
async function updateAccountJson(user) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      let jsonData = JSON.parse(decodedContent);

      // Update saldo pengguna
      jsonData[user.key].saldo = user.saldo;

      // Encode dan simpan perubahan pada account.json
      const updatedContent = JSON.stringify(jsonData, null, 2);
      const encodedContent = Buffer.from(updatedContent).toString('base64');

      await axios.put(apiUrl, {
         message: `Update saldo for ${user.key}`,
         content: encodedContent,
         sha: response.data.sha,
      }, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });
   } catch (error) {
      console.error('Gagal memperbarui saldo dalam account.json:', error.message);
      throw error;
   }
}

// Fungsi untuk membersihkan nomor dari karakter non-digit
function filterNumber(number) {
   return number.replace(/\D/g, '');
}