exports.run = {
   async: async (m, {
      client,
      Func, 
      users
   }) => {
      try {
         if (users.tutorial_opt === true) {
            if (m.text === '1') {
client.reply(m.chat, `# Cara Top Up Game :

beli kode_produk|id_game

• Contoh - Free Fire :
beli FF70|701025639
• Contoh - Mobile Legends :
beli DML2|1160977561 (13701)`, m);
users.tutorial_opt = false;
            }
            if (m.text === '2') {
client.reply(m.chat, `# Cara Beli Pulsa :

beli kode_produk|nomor_tujuan

• Contoh :
beli A25|083896835921`, m);
users.tutorial_opt = false;
            }
            if (m.text === '3') {
client.reply(m.chat, `# Cara Beli Kuota :

beli kode_produk|nomor_tujuan

• Contoh :
beli VXMA|083896835921`, m);
users.tutorial_opt = false;
            }
            if (m.text === '4') {
client.reply(m.chat, `# Cara Top Up Mobile Legends :

beli kode_produk|id (zone)

• Contoh :
beli DML2|1160977561 (13701)`, m);
users.tutorial_opt = false;
            }
      }
      } catch (e) {
         return console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   location: __filename
}