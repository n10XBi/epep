exports.run = {
   usage: ['signup'],
   category: 'manage account',
   async: async (m, {
      client,
      Func, 
      users, 
      command, 
      isPrefix
   }) => {
      try {
         users.stat_email = true;
         users.stat_password = false;
         users.stat_username = false;
         users.login_username = false; 
         users.login_password = false;
         users.email = '';
         users.password = '';
         users.username = '';
         client.reply(m.chat, '🚩 Silahkan kirimkan *Email* kamu yang aktif', m)
      } catch (e) {
         console.log(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   private: true,
   location: __filename
}
