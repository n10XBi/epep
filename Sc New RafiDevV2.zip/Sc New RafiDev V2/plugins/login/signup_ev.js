const axios = require('axios');
const moment = require('moment-timezone');
const nodemailer = require('nodemailer');

exports.run = {
   async: async (m, {
      client,
      Func, 
      users, 
      command, 
      isPrefix
   }) => {
      try {
         if (users.stat_email) {
            if (!/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ig.test(m.text)) return client.reply(m.chat, Func.texted('bold', '🚩 Invalid email.'), m)
            users.email = m.text;
            users.stat_email = false;
            users.stat_password = false;
            client.reply(m.chat, '🚩 Silahkan kirimkan *Username* (minimal 5 huruf)', m);
            users.stat_username = true;
            users.username = '';
         }
         else if (users.stat_username) {
            if (m.text.length < 5) return client.reply(m.chat, '🚩 Username Minimal 5 Huruf', m)
            if (m.text.includes('°')) return client.reply(m.chat, '🚩 Username tidak boleh mengandung karakter "°"', m);
            users.username = m.text;
            users.stat_username = false;
            users.stat_password = true;
            client.reply(m.chat, '🚩 Silahkan kirimkan *Password* (minimal 6 character)', m);
         }
         else if (users.stat_password) {
            if (m.text.length < 6) return client.reply(m.chat, '🚩 Password Minimal 6 Character', m)
            if (m.text.includes('°')) return client.reply(m.chat, '🚩 Password tidak boleh mengandung karakter "°"', m);
            users.password = m.text;
            users.stat_password = false;
            client.reply(m.chat, '*Proses Pembuatan . . .*', m);
            // proses pembuatan akun
            let number = (m.sender).split('@')[0]; 
            
            let email = users.email;
            let username = users.username;
            let password = users.password;
            
            let newUsername = username.trim();
            let filteredNumber = filterNumber(number.trim());
            
            // Check if email or username already exists
            const emailExists = await checkEmailExists(email);
            const usernameExists = await checkUsernameExists(newUsername);
            
            if (emailExists) {
               users.stat_email = false;
               users.stat_password = false;
               users.stat_username = false;
               users.login_username = false; 
               users.login_password = false;
               users.email = '';
               users.password = '';
               users.username = '';
               return client.reply(m.chat, 'Email already exists', m);
            }
            
            if (usernameExists) {
               users.stat_email = false;
               users.stat_password = false;
               users.stat_username = false;
               users.login_username = false; 
               users.login_password = false;
               users.email = '';
               users.password = '';
               users.username = '';
               return client.reply(m.chat, 'Username already exists', m);
            }
            
            await addAccessC(email.trim(), filteredNumber, password.trim(), Func, newUsername, client, m);
         }
      } catch (e) {
         console.log(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   private: true,
   location: __filename
}

async function addAccessC(email, number, password, Func, newUsername, client, m) {
  try {
  const gh = process.env.USERNAME_GH;
    const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
    const token = process.env.TOKEN_GH;

    const response = await axios.get(apiUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const content = response.data.content;
    const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
    const jsonData = JSON.parse(decodedContent);

    if (jsonData[`${email}°${newUsername}`]) {
      return client.reply(m.chat, `Username *${newUsername}* already exists.`, m);
    }

    jsonData[`${email}°${newUsername}°${number}`] = {
      "password": password, 
      "saldo": 0,
      "total_pembelian": 0,
      "total_pengeluaran": 0,
      "status": false,
      "account_create": moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm")
    };

    const updatedContent = JSON.stringify(jsonData, null, 2);
    const encodedContent = Buffer.from(updatedContent).toString('base64');

    await axios.put(apiUrl, {
      message: `Add new user ${newUsername}`,
      content: encodedContent,
      sha: response.data.sha,
    }, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    client.sendMessageModify(m.chat, `❒ *A C C O U N T*

○ Email : *${email}*
○ Number : *${number}*
○ Username : *${newUsername}*
○ Password : *${password}*


*Note :*
➥ Cek email anda, kode verifikasi telah dikirimkan. 
➥ Kirim code verifikasi ke nomor ini
➥ Kirim *\`profile\`* untuk mengecek profile akun. 

_*Jika terjadi Error / Bugs, Harap lapor ke Owner, Terimakasih*_


${global.footer}`, m, {
      largeThumb: true,
      thumbnail: global.db.setting.cover,
      url: global.db.setting.link
   });
     client.sendReact(m.chat, '✅', m.key);
     let users = global.db.users.find(v => v.jid == m.sender);
     let code = `${Func.randomInt(1000, 9999)}-${Func.randomInt(100, 999)}-${Func.randomInt(1000, 9000)}`;
     users.code = code;
     users.signup = true;

     // send email
     const transport = nodemailer.createTransport({
        service: process.env.USER_EMAIL_PROVIDER,
        auth: {
          user: process.env.USER_EMAIL,
          pass: process.env.USER_APP_PASSWORD
        }
      });

      const mailOptions = {
        from: {
          name: process.env.USER_NAME,
          address: process.env.USER_EMAIL
        },
        to: email,
        subject: 'SignUp Account',
        html: `<div style="padding:20px;border:1px dashed #222;font-size:15px"><tt>Hi <b>${m.pushName} 🛍️</b><br><br><img src="https://telegra.ph/file/0ae0ae20f254345e034b4.png" alt="Thumbnail"><br><br>Konfirmasikan email Anda untuk membuat Akun ${process.env.USER_NAME}. Kirim kode ini ke bot.<br><center><h1>${code}</h1></center>Atau salin dan tempel URL di bawah ini ke browser Anda : <a href="https://wa.me/${client.decodeJid(client.user.id).split('@')[0]}?text=${code}">https://wa.me/${client.decodeJid(client.user.id).split('@')[0]}?text=${code}</a><br><br><hr style="border:0px; border-top:1px dashed #222"><br>With, <b>© RafiDev</b></tt></div>`
      };

      transport.sendMail(mailOptions, function(err, data) {
        if (err) return client.reply(m.chat, Func.texted('bold', `❌ SMTP Error !!`), m);
        return client.reply(m.chat, Func.texted('bold', `✅ Periksa pesan masuk Email Anda untuk mendapatkan kode verifikasi.`), m);
      });
  } catch (error) {
    console.error(`Failed to add user ${newUsername}: ${error.message}`);
    return client.reply(m.chat, "❌ Failed to add user. Please try again later.", m);
  }
}

function filterNumber(number) {
  return number.replace(/\D/g, '');
}

async function checkEmailExists(email) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Get the content of the account.json file
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Check if the email exists in the JSON data
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const [emailKey] = key.split('°');

            if (emailKey === email) {
               return true;
            }
         }
      }

      return false; // Email does not exist
   } catch (error) {
      console.error('Failed to check email existence:', error.message);
      throw error;
   }
}

async function checkUsernameExists(username) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Get the content of the account.json file
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Check if the username exists in the JSON data
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const [, usernameKey] = key.split('°');

            if (usernameKey === username) {
               return true;
            }
         }
      }

      return false; // Username does not exist
   } catch (error) {
      console.error('Failed to check username existence:', error.message);
      throw error;
   }
}