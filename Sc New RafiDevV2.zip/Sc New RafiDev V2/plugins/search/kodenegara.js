const fetch = require('node-fetch');

exports.run = {
   usage: ['kodenegara'],
   use: 'country',
   category: 'search',
   async: async (m, { client, Func, args, isPrefix, command }) => {
      try {
         if (!args || !args[0]) return client.reply(m.chat, Func.example(isPrefix, command, 'Afghanistan'), m);

         const countryName = args[0].toLowerCase();

         const apiUrl = 'https://gist.githubusercontent.com/anubhavshrimal/75f6183458db8c453306f93521e93d37/raw/f77e7598a8503f1f70528ae1cbf9f66755698a16/CountryCodes.json';

         const response = await fetch(apiUrl);
         const countryData = await response.json();

         const result = countryData.find(country => country.name.toLowerCase() === countryName);

         if (result) {
            const caption = `*❒ K O D E - N E G A R A*\n\n`
               + `○ *Name:* ${result.name}\n`
               + `○ *Dial Code:* ${result.dial_code}\n`
               + `○ *Code:* ${result.code}`;

            client.reply(m.chat, caption + `

${global.footer}`, m);
         } else {
            client.reply(m.chat, Func.texted('bold', '❌ Country not found.'), m);
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};