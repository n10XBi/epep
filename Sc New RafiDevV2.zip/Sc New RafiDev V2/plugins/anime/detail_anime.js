const malScraper = require('mal-scraper');

exports.run = {
  usage: ['detail-anime'],
  use: 'url',
  category: 'anime', 
  async: async (m, { args, client, isPrefix, command, Func }) => {
    try {
      if (!args[0]) return client.reply(m.chat, Func.example(isPrefix, command, 'https://myanimelist.net/anime/20047/Sakura_Trick'), m);

      const url = args[0];
      if (!args[0].match('myanimelist.net')) return client.reply(m.chat, global.status.invalid, m)
      client.sendReact(m.chat, '🕘', m.key)

      const data = await malScraper.getInfoFromURL(url);

      const synopsis = data.synopsis.replace(/\n\n/g, '\n');

      const characterList = data.characters.map(char => {
        return `○ Name : ${char.name}
○ Role : ${char.role}
○ Seiyuu : ${char.seiyuu.name}]
*~~~*`;
      }).join('\n');

      const staffList = data.staff.map(staff => {
        return `○ Staff : ${staff.name}
○ Staff Role : (${staff.role})
*~~~*`;
      }).join('\n');

      const response = `*❒  D E T A I L - A N I M E*
      
📺 *Judul:* ${data.title}
*______________________*

📝 *Sinopsis:* ${synopsis}
*______________________*

🎭 *Karakter:*
${characterList}
*______________________*

👥 *Staf:*
${staffList}
*______________________*

🔗 *URL:* ${url}

${global.footer}`;

      client.sendFile(m.chat, data.picture, 'image.jpg', response, m);
      Func.delay(1500);
      client.sendReact(m.chat, '✅', m.key);
    } catch (error) {
      console.error(error);
      client.reply(m.chat, 'Terjadi kesalahan saat memproses permintaan.', m);
    }
  }
};
