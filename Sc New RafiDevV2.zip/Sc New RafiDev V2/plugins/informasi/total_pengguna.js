const axios = require('axios');

exports.run = {
   usage: ['total'],
   async: async (m, {
      client,
      Func, 
      args
   }) => {
      try {
         if (args[0] === 'pengguna') {
         const totalUsers = await getTotalUsers();
         client.reply(m.chat, `*Total Pengguna :* ${totalUsers}`, m);
         } 
      } catch (e) {
         console.log(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   location: __filename
}

async function getTotalUsers() {
   try {
const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Hitung total pengguna
      const totalUsers = Object.keys(jsonData).length;
      return totalUsers;
   } catch (error) {
      console.error('Failed to get total users:', error.message);
      throw error;
   }
}