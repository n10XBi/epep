const { createCanvas, loadImage, registerFont } = require('canvas');
const axios = require('axios');
const fetch = require('node-fetch');
const path = require('path');

exports.run = {
   usage: ['profile'],
   use: 'mention or reply',
   category: 'manage account',
   async: async (m, { client, Func, users, env, blockList, isPrefix }) => {
      try {
         let user = global.db.users.find(v => v.jid == m.sender);
         let number = (m.sender).split('@')[0];
         const profileData = await getProfileData(number);
         if (!profileData) {
            return client.reply(m.chat, "❗ Data profile kosong.", m);
         }
         if (!profileData.status) {
            return client.reply(m.chat, "❗ Akun Anda belum terverifikasi.", m);
         }
         let birthday = user.birthday ? `${user.birthdayTgl} - ${user.birthdayBln} - ${user.birthdayThn}` : '-';
         let blocked = blockList.includes(m.sender) ? true : false;
         let _own = [...new Set([env.owner, ...global.db.setting.owners])];
         if (isNaN(number)) return client.reply(m.chat, Func.texted('bold', `🚩 Invalid number.`), m);
         if (number.length > 15) return client.reply(m.chat, Func.texted('bold', `🚩 Invalid format.`), m);

         let userJid = number + '@s.whatsapp.net';

         let pic;
         try {
            client.sendReact(m.chat, '🕒', m.key);
            pic = await client.profilePictureUrl(userJid, 'image');
         } catch (e) {
            console.error(e);
         } finally {
            // Jika pic tidak tersedia, gunakan gambar default
            if (!pic) {
               pic = './media/image/default.jpg';
            }

            // Load background and profile picture
            const bg = await loadImage('https://i.ibb.co/rvsrysZ/1-20240319-174658-0000.png');
            const profilePic = await loadImage(pic);

            // Register font
            registerFont(path.join('media/fonts/maxim.ttf'), { family: 'Maxim' });

            // Create canvas
            const canvas = createCanvas(bg.width, bg.height);
            const ctx = canvas.getContext('2d');

            // Draw background
            ctx.drawImage(bg, 0, 0, bg.width, bg.height);

            // Draw profile picture (centered and circular)
            const centerX = canvas.width / 1.3;
            const centerY = canvas.height / 2.14;
            const radius = canvas.width / 6.4; // Diameter = 1/6 of width (19:6 aspect ratio)

            ctx.save();
            ctx.beginPath();
            ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI, false);
            ctx.clip();
            ctx.drawImage(profilePic, centerX - radius, centerY - radius, radius * 2, radius * 2);
            ctx.restore();

            // Draw text on the left of pic
            const leftText = env.bot_name;
            ctx.font = '20px "Maxim"';
            ctx.fillStyle = '#000000';
            ctx.fillText(leftText, centerX - radius - 300, centerY + 127);

            // Draw text below m.pushName
            const belowText = m.pushName;
            ctx.font = '27px "Maxim"';
            ctx.fillStyle = '#FFBE2D';
            ctx.textAlign = 'left';
            ctx.fillText(belowText, centerX - radius - 240, centerY + 30);

            ctx.font = '27px "Maxim"';
            ctx.fillStyle = '#FFBE2D'; // Yellow text color
            ctx.textAlign = 'left';
            ctx.fillText('Rp ' + profileData.saldo, centerX - radius - 220, centerY + 60);

            // Convert canvas to buffer and send as file
            const buffer = canvas.toBuffer('image/jpeg');
            client.sendMessageModify(m.chat, `❒ *P R O F I L E*

○ Email : ${profileData.email}
○ Username : ${profileData.username}
○ Saldo Deposit : Rp. ${Func.formatNumber(profileData.saldo)}
○ Total Pembelian : ${Func.formatNumber(profileData.total_pembelian)}
○ Total Pengeluaran : Rp. ${Func.formatNumber(profileData.total_pengeluaran)}
○ Tanggal Pembuatan Akun : ${profileData.account_create}`, m, {
               largeThumb: true,
               thumbnail: buffer, 
               url: global.db.setting.link
            });

            // React to indicate completion
            await Func.delay(1500);
            client.sendReact(m.chat, '✅', m.key);
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   cache: true,
   location: __filename
};

async function getProfileData(number) {
   try {
const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Cari profile berdasarkan nomor
      let profileData = null;
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const userInfoNumber = key.split('°')[2]; // Ambil number dari key

            if (userInfoNumber === number) {
               const [email, username] = key.split('°');
               profileData = {
                  email: email,
                  username: username,
                  saldo: userInfo.saldo,
                  total_pembelian: userInfo.total_pembelian,
                  total_pengeluaran: userInfo.total_pengeluaran,
                  account_create: userInfo.account_create,
                  status: userInfo.status // Tambahkan status akun
               };
               break;
            }
         }
      }

      return profileData; // Kembalikan profile data
   } catch (error) {
      console.error('Failed to get profile data:', error.message);
      throw error;
   }
}

