exports.run = {
   usage: ['payment'],
   hidden: ['pembayaran'], 
   category: 'informasi',
   async: async (m, {
      client,
      setting
   }) => {
         await client.sendFile(m.chat, setting.qris, 'qris.jpg', setting.payment, m)
   },
   error: false,
   location: __filename
}