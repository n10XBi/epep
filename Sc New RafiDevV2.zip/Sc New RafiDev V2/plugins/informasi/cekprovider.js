const noTelp = require('no-telp');

exports.run = {
   usage: ['cekprovider'],
   use: '6287745690302',
   category: 'informasi', 
   async: async (m, { client, args, Func, isPrefix, command }) => {
      try {
         if (!args || !args[0]) {
            return client.reply(m.chat, `*❒ Cek Provider*

• *Example :* ${isPrefix}${command} 6287745690302`, m);
         }

         const nomorTelp = args[0];
         const result = noTelp.getOperator(nomorTelp, true); // Menggunakan validasi karakter

         const caption = `*❒ C E K - P R O V I D E R*\n\n`
            + `○ *Nomor Telepon:* ${nomorTelp}\n`
            + `○ *Operator:* ${result.operator}\n`
            + `○ *Kartu:* ${result.card}\n`
            + `○ *Message:* ${result.message}\n`
            + `○ *Valid:* ${result.valid ? 'Yes' : 'No'}`;
         
         client.reply(m.chat, caption, m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   limit: false,
   location: __filename
};