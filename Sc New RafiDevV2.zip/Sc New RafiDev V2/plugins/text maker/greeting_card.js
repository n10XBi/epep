const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');

// Function to chunk text into lines
function chunkText(text, maxCharacters) {
   const words = text.split(' ');
   let lines = [''];
   let currentLine = 0;

   for (const word of words) {
      if (lines[currentLine].length + word.length <= maxCharacters) {
         lines[currentLine] += word + ' ';
      } else {
         lines[++currentLine] = word + ' ';
      }
   }

   return lines.map(line => line.trim());
}

exports.run = {
   usage: ['greeting_card'],
   use: 'judul|isi pesan',
   category: 'text maker',
   async: async (m, { client, text, Func, isPrefix, command }) => {
      try {
         const [title, docText] = text.split('|');

         if (!title || !docText) return client.reply(m.chat, Func.example(isPrefix, command, 'Selamat Ulang Tahun|Semoga Panjang Umur Dan Sehat Selalu'), m);

         // Load fonts
         registerFont(path.join('media/fonts/Ants Valley - Personal Use.otf'), { family: 'TitleFont' });
         registerFont(path.join('media/fonts/Alegreya-Medium.ttf'), { family: 'TextFont' });

         // Load background
         const bg = await loadImage('https://i.ibb.co/ZMCkhqg/image.jpg');

         // Create canvas
         const canvas = createCanvas(bg.width, bg.height);
         const ctx = canvas.getContext('2d');

         // Draw background
         ctx.drawImage(bg, 0, 0, bg.width, bg.height);

         // Draw title text
         ctx.font = 'bold 70px "TitleFont"';
         ctx.fillStyle = '#536F5D';
         ctx.textAlign = 'center';

         // Check if title character count exceeds 7
         if (title.length > 13) {
            const lines = chunkText(title, 13);
            const lineHeight = 100;

            lines.forEach((line, index) => {
               const y = 190 + index * lineHeight;
               ctx.fillText(line, bg.width / 2.1, y);
            });
         } else {
            ctx.fillText(title, bg.width / 2, 150);
         }

         // Draw document text
         const maxCharsPerLine = 50;
         const lines = chunkText(docText, maxCharsPerLine);
         const lineHeight = 25;

         ctx.font = '15px "TextFont"';
         ctx.fillStyle = '#536F5D';
         ctx.textAlign = 'left';
         ctx.textBaseline = 'top';

         lines.forEach((line, index) => {
            const y = 310 + index * lineHeight;
            ctx.fillText(line, 170, y);
         });

         // Convert canvas to buffer and send as file
         const buffer = canvas.toBuffer('image/jpeg');
         client.sendFile(m.chat, buffer, 'dokumen.jpg', `*✨ Ini kak hasil nya*`, m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.texted('bold', `🚩 Can't generate dokumen image.`), m);
      }
   },
   error: false,
   limit: true,
   cache: true,
   location: __filename
};
