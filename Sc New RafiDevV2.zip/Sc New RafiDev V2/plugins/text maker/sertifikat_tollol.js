const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');

exports.run = {
   usage: ['sertifikat-tollol'],
   use: 'name',
   category: 'text maker',
   async: async (m, { client, text, Func, isPrefix, command }) => {
      try {
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'Udin'), m);

         // Load font
         registerFont(path.join('media/fonts/Neuton-Extrabold.ttf'), { family: 'UcapanFont' });

         // Load background
         const bg = await loadImage('https://i.ibb.co/zPRjVJQ/image.jpg');

         // Create canvas
         const canvas = createCanvas(bg.width, bg.height);
         const ctx = canvas.getContext('2d');

         // Draw background
         ctx.drawImage(bg, 0, 0, bg.width, bg.height);

         // Draw text
         ctx.font = '45px "UcapanFont"';
         ctx.fillStyle = '#372205'; // Dark brown text color
         ctx.textAlign = 'center';
         ctx.fillText(text, bg.width / 2, bg.height / 2.5);

         // Convert canvas to buffer and send as file
         const buffer = canvas.toBuffer('image/jpeg');
         client.sendFile(m.chat, buffer, 'ucapan.jpg', `*Ucapan*`, m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.texted('bold', `🚩 Can't generate ucapan image.`), m);
      }
   },
   error: false,
   limit: true,
   cache: true,
   location: __filename
};