const fetch = require('node-fetch');
const tls = require('tls');
const { Certificate } = require('crypto');

exports.run = {
   usage: ['cekstatus-website'],
   use: 'url',
   category: 'website', 
   async: async (m, { client, args, isPrefix, command }) => {
      try {
         if (!args || !args[0]) {
            return client.reply(m.chat, `• *Example :* ${isPrefix + command} yanamiku.shop`, m);
         }

         const url = args[0];

         // Mengecek status website
         const websiteStatus = await checkWebsiteStatus(url);
         const sslInfo = await getSSLInfo(url);

         // Menyiapkan hasil cek website
         let result = `*❒ Cek Website - ${url}*\n\n`;
         result += `○ *Status Website:* ${websiteStatus}\n`;

         // Menambahkan informasi SSL jika website aktif
         if (websiteStatus === 'Aktif') {
            result += `○ *Status SSL:* ${sslInfo.status}\n`;
            result += `○ *SHA1 Sidik Jari:* ${sslInfo.sha1Fingerprint}\n`;
            result += `○ *SHA2 Sidik Jari:* ${sslInfo.sha256Fingerprint}\n`;
            result += `○ *Dikeluarkan Oleh:* ${sslInfo.issuer}\n`;
         }

         client.reply(m.chat, result, m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};

async function checkWebsiteStatus(url) {
   try {
      const response = await fetch(`https://${url}`);
      return response.ok ? 'Aktif' : 'Tidak Aktif';
   } catch (error) {
      return 'Tidak Aktif';
   }
}

async function getSSLInfo(url) {
   try {
      const socket = tls.connect(443, url, { servername: url });
      await new Promise(resolve => socket.once('secureConnect', resolve));

      const certificate = socket.getPeerCertificate();
      const sha1Fingerprint = getFingerprint(certificate.fingerprint256, 'sha1');
      const sha256Fingerprint = getFingerprint(certificate.fingerprint256, 'sha256');

      return {
         status: 'Aktif',
         sha1Fingerprint,
         sha256Fingerprint,
         issuer: certificate.issuer.CN,
      };
   } catch (error) {
      return { status: 'Tidak Aktif' };
   }
}

function getFingerprint(base64Fingerprint, algorithm) {
   const buffer = Buffer.from(base64Fingerprint, 'base64');
   return buffer.toString('hex').toUpperCase().match(/.{2}/g).join(':');
}