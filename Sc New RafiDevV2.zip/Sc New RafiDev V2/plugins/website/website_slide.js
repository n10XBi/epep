const axios = require('axios');

exports.run = {
  usage: ['website-slide'], 
  category: 'website',
  async: async (m, { client, text, isPrefix, command }) => {
    try {
      const yanamiku = client;
      if (!text) return yanamiku.reply(m.chat, `• Example :
${isPrefix + command} hii kamuuu 😍
ga kerasa ya..
udah mau lebaran aja :( | minal aidzin wal faidzin
taqabalallahu minna
wa minkum | selamat hari raya idul fitri!
mohon maaf lahir dan batin
dari aku buat kamu ✨ | aku seneng deh lebaran kali ini
aku bisa ucapin ke kamu 🤍`, m)

      const githubUsername = 'Raffimaker01';
      const repositoryName = 'bot-web';
      const randomFilename = generateRandomString() + '.html';
      const websiteName = `https://raffimaker01.github.io/bot-web/${randomFilename.replace('.html', '')}`;
      const githubApiToken = process.env.TOKEN_GH;

      const htmlCode = `<!DOCTYPE html>
<html>
<meta charset='UTF-8'/><meta content='width=device-width, initial-scale=1, user-scalable=1, minimum-scale=1, maximum-scale=5' name='viewport'/><meta content='IE=edge' http-equiv='X-UA-Compatible'/>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Caveat&display=swap" rel="stylesheet">
  
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
  <script src="https://unpkg.com/typeit@8.7.0/dist/index.umd.js"></script>
  <link href="https://feeldreams.github.io/inidariku/style.css" rel="stylesheet" type="text/css" />
  <script src="https://kit.fontawesome.com/4f3ce16e3e.js" crossorigin="anonymous"></script>
  
<head>
<title>Selamat Hari Raya Idul Fitri</title>
  <link rel="icon" type="image/x-icon" href="https://malasid.github.io/favicon.png">
<meta name="description" content="Selamat Hari Raya Idul Fitri">
<!-- 
  Made with love by Rayys!
  
     Blog: feeldream.id
     Instagram: @rayyarrr
     TikTok: @feelthisray
     Email: rayyar73@gmail.com
     
  Thanks to all <3
-->
</head>
<body>
  
   <!-- Ganti Audio di sini -->
   <audio src="https://inidariku.feeldream.repl.co/lbrn.mp3" id="linkmp3" class="sembunyi"></audio>
   
   <div id="bodyblur">
     <!-- Wallpaper / Background --><img src="https://feeldreams.github.io/pics/awan8.jpg" id="wallpaper"/>
   </div>
   
   <div id='Content'>

     <div id="ftAwal">
       <!-- Stiker Pembuka -->
       <img src="https://feeldreams.github.io/pandaputih.gif" id="ftoAwal"/>
     </div>

     <div id="loveIn">
       <!-- Tombol LOVE --><label class='lovein'>&#10084;</label>
     </div>
     <p id="ket">Sentuh LOVEnya!</p>

     <div class="kumpulanstiker">
         <!-- Stiker untuk Konten -->
         <img src="https://feeldreams.github.io/pusn.gif" id="fotostiker"/>
         <img src="https://feeldreams.github.io/bunga.gif" id="fotostiker1"/>
         <img src="https://feeldreams.github.io/ngumpet.gif" id="fotostiker2"/>
         <img src="https://feeldreams.github.io/pandaketawa2.gif" id="fotostiker3"/>
         <img src="https://feeldreams.github.io/emawh.gif" id="fotostiker4"/>
     </div>
     
     <div><div id='pergeseran'>
      
<!-- Pesan -->
${generateHTMLMessages(text)}

     </div></div>

     <div id="Tombol">
       <a onClick="multifungsi()">
         <b id="tmbl">Next &#128073;</b>
       </a>
     </div>
     
   </div>

<script>
const body = document.querySelector("body"); const iniwp = [];iden = 1; const swalst = Swal.mixin({timer: 2500, allowOutsideClick: false, showConfirmButton: false, timerProgressBar: true, imageHeight: 90,}); audio = new Audio('' + linkmp3.src); ftganti=0;fungsi=0;fungsiAwal=0;deffotostiker=fotostiker.src;function berjatuhan() {const heart = document.createElement("div"); heart.className = "fas fa-heart"; heart.style.left = (Math.random() * 90)+"vw"; heart.style.animationDuration = (Math.random()*3)+2+"s"; body.appendChild(heart);} setInterval(function name(params) {var heartArr = document.querySelectorAll(".fa-heart"); if (heartArr.length > 100) {heartArr[0].remove()}},100);Content.style = "opacity:1;margin-top:14vh"; const swals = Swal.mixin({allowOutsideClick: false, cancelButtonColor: '#FF0040', imageHeight: 80,});   
</script>
<script src="https://malasid.github.io/html/idfit.js"></script>
<!-- Sampai Sini -->
</body>
</html>`;

      // Create repository file
      const createFileResponse = await createFileOnGithub(githubUsername, repositoryName, githubApiToken, randomFilename, htmlCode);

      if (createFileResponse.status === 201) {
        yanamiku.reply(m.chat, `Website romantis berhasil dibuat!\n\n${websiteName}

Tunggu Beberapa Menit Dan Website Akan Jadi`, m);
      } else {
        yanamiku.reply(m.chat, 'Gagal membuat website romantis', m);
      }
    } catch (e) {
      console.error(e);
      yanamiku.reply(m.chat, 'Terjadi kesalahan', m);
    }
  },
  error: false,
  premium: true, 
  limit: true, 
  location: __filename
};

function generateHTMLMessages(text) {
  const messages = text.split(/\s*\|\s*/);
  let html = '';

  messages.forEach(message => {
    const lines = message.trim().split('\n').map(line => `<br>${line}`);
    html += `<p><b><span>${lines.join('')}</span></b></p>\n\n`;
  });

  return html;
}

async function createFileOnGithub(username, repository, token, filename, content) {
  const apiUrl = `https://api.github.com/repos/${username}/${repository}/contents/${filename}`;
  const encodedContent = Buffer.from(content).toString('base64');

  return axios.put(apiUrl, {
    message: `Add ${filename}`,
    content: encodedContent,
  }, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}

function generateRandomString(length = 10) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}