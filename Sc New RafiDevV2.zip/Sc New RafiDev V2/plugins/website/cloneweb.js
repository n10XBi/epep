const axios = require('axios');

exports.run = {
  usage: ['cloneweb'],
  use: 'url',
  category: 'website',
  async: async (m, { client, args, isPrefix, command }) => {
    try {
      const yanamiku = client;
      if (!args[0]) return yanamiku.reply(m.chat, `• *Example :*
${isPrefix + command} https://kusonime.com`, m);
      const githubUsername = 'Raffimaker01';
      const repositoryName = 'bot-web';
      const randomFilename = generateRandomString() + '.html';
      const websiteName = `https://raffimaker01.github.io/bot-web/${randomFilename.replace('.html', '')}`;
      const githubApiToken = process.env.TOKEN_GH;
      const htmlCode = `<!DOCTYPE html>
<html>
<head>
	<title>YanaMiku - WebClone</title>
</head>
<frameset rows="100%,*" frameborder="no" border="0" framespacing="0">
	<frame name="main" scrolling="yes" noresize src="${args[0]}">
	<noframes>
		<body>
			<p>Your browser does not support frames. Please click <a href="${args[0]}">here</a> to continue.</p>
		</body>
	</noframes>
</frameset>
</html>`;

      // Create repository file
      const createFileResponse = await createFileOnGithub(githubUsername, repositoryName, githubApiToken, randomFilename, htmlCode);

      if (createFileResponse.status === 201) {
        yanamiku.reply(m.chat, `Berhasil Meng-Clone Website :
        
${websiteName}

_Tunggu 1 menit website akan jadi_

${global.footer}`, m);
      } else {
        yanamiku.reply(m.chat, 'Gagal membuat website', m);
      }
    } catch (e) {
      console.error(e);
      yanamiku.reply(m.chat, 'Terjadi kesalahan', m);
    }
  },
  error: false,
  limit: true, 
  location: __filename
};

async function createFileOnGithub(username, repository, token, filename, content) {
  const apiUrl = `https://api.github.com/repos/${username}/${repository}/contents/${filename}`;
  const encodedContent = Buffer.from(content).toString('base64');

  return axios.put(apiUrl, {
    message: `Add ${filename}`,
    content: encodedContent,
  }, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}

function generateRandomString(length = 4) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}