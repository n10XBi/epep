const axios = require('axios');

exports.run = {
  usage: ['website-minta-pap'],
  use: 'isi pesan', 
  category: 'website',
  async: async (m, { client, text, isPrefix, command }) => {
    try {
      const yanamiku = client;
      if (!text) return yanamiku.reply(m.chat, `• Example :
${isPrefix + command} Minta Pap, Soalnya Kamu Imut, Boleh Gak Nih`, m)
      const githubUsername = 'Raffimaker01';
      const repositoryName = 'bot-web';
      const randomFilename = generateRandomString() + '.html';
      const websiteName = `https://raffimaker01.github.io/bot-web/${randomFilename.replace('.html', '')}`;
      const githubApiToken = process.env.TOKEN_GH;
      const htmlCode = `<!DOCTYPE html>
<html>
<meta charset='UTF-8'/>
<meta content='width=device-width, initial-scale=1, user-scalable=1, minimum-scale=1, maximum-scale=5' name='viewport'/><script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
<meta content='IE=edge' http-equiv='X-UA-Compatible'/><link href="https://feeldreams.github.io/hainona/style.css" rel="stylesheet" type="text/css" />

<head>
<title>${text}</title>
<meta name="description" content="${text}">
<link rel="icon" type="image/x-icon" href="https://malasid.github.io/favicon.png">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
	
   <!-- Ganti Audio di sini --><audio src="https://feeldreams.github.io/hainona/hainona.mp3" id="linkmp3"></audio><script>audio = new Audio('' + linkmp3.src);</script>
   
   <div id="bodyblur">
     <!-- Wallpaper --><img src="https://feeldreams.github.io/hainona/wpwp.jpg" id="wallpaper"/>
   </div>

   <div id='Content'>
   	
     <div id="suratin">
       <!-- Tombol Surat --><img src="https://rayyscoding.github.io/envelope.png"/>
     </div>
     <p id="ket">Klik Pesannya!</p>
   
     <div>
         <!-- Stiker untuk Konten -->
         <img src="https://feeldreams.github.io/peachgaruk.gif" id="fotoakhir"/>
         <img src="https://feeldreams.github.io/peachbunga2.gif" id="fotoakhir1"/>
         <img src="https://feeldreams.github.io/peachhello.gif" id="fotoakhir2"/>
         <img src="https://feeldreams.github.io/peachcekrek.gif" id="fotoakhir3"/>
         <img src="https://feeldreams.github.io/peachlove.gif" id="fotoakhir4"/>
         <img src="https://feeldreams.github.io/peachktw.gif" id="fotoakhir5"/>

         <img src="https://feeldreams.github.io/peach22.gif" id="fotoAkhir"/>
     </div>
     <div><blockquote id='bq'>
  
       <!-- Konten Penerapan -->
       <p id="kalimat">Membeli Barang Antik</p>
       <p id="kalimata">di Kota Cilacap..  😋</p>
       <p id="kalimatb">Hai Nona Cantik,</p>
       <p id="kalimatc">Give Me Your Pap ❤️😍</p>
       <p id="kalimatd">Ahaha..</p>
       <p id="kalimatd2">Cuaakkss~</p>
       
       <!-- Konten Pertanyaan -->
       <p id="kalimat2">${text}</p>

       <!-- Konten Jawaban -->
       <p id="kalimat3">Jawabanmu: </p>
       <p id="kalimatb3">Kirim ke WhatsApp aku ya!</p>
     </blockquote></div>
   
     <!-- Tombol Multifungsi -->
     <div id="Tombol">
       <a id="By" onClick="multifungsi()">
         <b id="tmbl">Lanjut</b>
         <b id="tmbl2">💌 Balas</b>
       </a>
     </div>
     
   </div>

<!-- Jangan Edit Bagian Ini --><script>
  const swalst = Swal.mixin({timer: 2777, allowOutsideClick: false, showConfirmButton: false, timerProgressBar: true, imageHeight: 100,}); ftom=0;jikatom=0;ftganti=0;fungsi=0; const swals = Swal.mixin({allowOutsideClick: false, cancelButtonColor: '#FF0040', imageWidth: 100, imageHeight: 100,}); const body = document.querySelector("body");function createHeart() {const heart = document.createElement("div"); heart.className = "fas fa-heart"; heart.style.left = (Math.random() * 90)+"vw"; heart.style.animationDuration = (Math.random()*3)+2+"s"; body.appendChild(heart);} setInterval(function name(params) {var heartArr = document.querySelectorAll(".fa-heart"); if (heartArr.length > 100) {heartArr[0].remove()}},100);

  function mulaikonten() {
                          setTimeout(fmketik1,1200);setTimeout(mketik1,1200);
                          setTimeout(fmketik2,2500);setTimeout(mketik2,2500);
                          setTimeout(fmketik3,4100);setTimeout(mketik3,4100);
                          setTimeout(fmketik4,5300);setTimeout(mketik4,5300);
                          setTimeout(fmketik5,6300);setTimeout(mketik5,6300);
                         }
  async function menuju(){await swals.fire('OK!', 'Kirim pesan ke WhatsApp aku, ya!', 'success');window.location = "https://api.whatsapp.com/send?phone=&text=" + pesanwhatsapp;Tombol.style="margin-top:15px;opacity:1;transform: scale(1);";}
</script>
<script src="https://malasid.github.io/html/dapetpap.js"></script>
<!-- Sampai Sini -->
</body>
</html>`;

      // Create repository file
      const createFileResponse = await createFileOnGithub(githubUsername, repositoryName, githubApiToken, randomFilename, htmlCode);

      if (createFileResponse.status === 201) {
        yanamiku.reply(m.chat, `Website romantis berhasil dibuat!\n\n${websiteName}

Tunggu Beberapa Menit Dan Website Akan Jadi`, m);
      } else {
        yanamiku.reply(m.chat, 'Gagal membuat website romantis', m);
      }
    } catch (e) {
      console.error(e);
      yanamiku.reply(m.chat, 'Terjadi kesalahan', m);
    }
  },
  error: false,
  premium: true, 
  limit: true, 
  location: __filename
};

async function createFileOnGithub(username, repository, token, filename, content) {
  const apiUrl = `https://api.github.com/repos/${username}/${repository}/contents/${filename}`;
  const encodedContent = Buffer.from(content).toString('base64');

  return axios.put(apiUrl, {
    message: `Add ${filename}`,
    content: encodedContent,
  }, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}

function generateRandomString(length = 10) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}